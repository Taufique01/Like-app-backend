python -m unittest tests.testAPI
